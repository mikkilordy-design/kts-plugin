@echo off
rem Remove KTC platform for the current user. Add -RemoveLogs to delete logs too.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall.ps1" %*
echo.
pause
