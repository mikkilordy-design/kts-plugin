﻿<#
.SYNOPSIS
    Удаляет платформу KTC у текущего пользователя.

.DESCRIPTION
    Останавливает клиент KTC и убирает его из автозапуска, удаляет KTC.addin и Loader из
    %AppData%\Autodesk\Revit\Addins\20XX\ для всех версий Revit, клиент, локальные версии, кэш, настройки
    и неотправленные данные из %LocalAppData%\kts-project-plugin\KTC.
    Логи остаются, если не указан -RemoveLogs. Revit нужно закрыть.

.EXAMPLE
    .\uninstall.ps1
    .\uninstall.ps1 -RemoveLogs
#>
[CmdletBinding()]
param(
    [switch] $RemoveLogs,

    [ValidateSet(2022, 2023, 2024, 2025, 2026, 2027)]
    [int[]] $RevitVersions = @(2022, 2023, 2024, 2025, 2026, 2027),

    [string] $AddinsRoot,
    [string] $LocalRoot
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Join-Parts([string[]] $parts) { [System.IO.Path]::Combine($parts) }

if (-not $AddinsRoot) { $AddinsRoot = Join-Parts @($env:APPDATA, 'Autodesk', 'Revit', 'Addins') }
if (-not $LocalRoot) { $LocalRoot = Join-Parts @($env:LOCALAPPDATA, 'kts-project-plugin', 'KTC') }

$failed = 0
function Remove-Safely([string] $path) {
    if (-not (Test-Path -LiteralPath $path)) { return }
    try {
        Remove-Item -LiteralPath $path -Recurse -Force
        Write-Host "Удалено: $path"
    }
    catch {
        $script:failed++
        Write-Warning "Не удалось удалить $path ($($_.Exception.Message)). Закройте Revit и повторите."
    }
}

# Клиент KTC: остановить и убрать из автозапуска.
Get-Process -Name 'KtsProjectPlugin.Client' -ErrorAction SilentlyContinue | ForEach-Object {
    try { $_.Kill(); $_.WaitForExit(5000) | Out-Null } catch { }
}
if ([System.Environment]::OSVersion.Platform -eq [System.PlatformID]::Win32NT) {
    Remove-ItemProperty -LiteralPath 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' -Name 'KTC' -ErrorAction SilentlyContinue
}

if (@(Get-Process -Name 'Revit' -ErrorAction SilentlyContinue).Count -gt 0) {
    Write-Warning 'Revit запущен — часть файлов занята. Закройте Revit для полного удаления.'
}

foreach ($year in $RevitVersions) {
    $dir = Join-Parts @($AddinsRoot, "$year")
    Remove-Safely (Join-Parts @($dir, 'KTC.addin'))
    Remove-Safely (Join-Parts @($dir, 'KTC'))
}

if ($RemoveLogs) {
    Remove-Safely $LocalRoot
}
elseif (Test-Path -LiteralPath $LocalRoot) {
    Get-ChildItem -LiteralPath $LocalRoot -Force | Where-Object { $_.Name -ne 'logs' } | ForEach-Object { Remove-Safely $_.FullName }
}

# Пустые папки KTC и компании больше не нужны.
if ((Test-Path -LiteralPath $LocalRoot) -and @(Get-ChildItem -LiteralPath $LocalRoot -Force).Count -eq 0) {
    Remove-Item -LiteralPath $LocalRoot -Force
}
$company = Split-Path -Parent $LocalRoot
if ((Test-Path -LiteralPath $company) -and @(Get-ChildItem -LiteralPath $company -Force).Count -eq 0) {
    Remove-Item -LiteralPath $company -Force
}

if ($failed -gt 0) {
    Write-Warning "Удаление завершено не полностью ($failed ошибок)."
    exit 1
}
Write-Host 'Платформа KTC удалена.' -ForegroundColor Green
