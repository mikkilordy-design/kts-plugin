﻿<#
.SYNOPSIS
    Устанавливает или обновляет платформу KTC для текущего пользователя (без прав администратора).

.DESCRIPTION
    1. Находит установленные Revit 2022–2027.
    2. Кладёт Loader нужной сборки и KTC.addin в %AppData%\Autodesk\Revit\Addins\20XX\.
    3. Пишет bootstrap-конфиг %LocalAppData%\kts-project-plugin\KTC\bootstrap.json
       (существующие закрепление версии и режим разработчика сохраняются, если не заданы параметрами).
    4. Скачивает текущую версию платформы.
    5. Ставит клиент KTC (значок в трее) в %LocalAppData%\kts-project-plugin\KTC\client\, добавляет его
       в автозапуск при входе в Windows (HKCU\…\Run, без прав администратора) и запускает.
       Дальше обновления скачивает клиент — при входе в Windows и по кнопке «Обновить», когда Revit закрыт.
    Повторный запуск обновляет Loader. Revit на время установки нужно закрыть.

    Обычно запускается двойным щелчком по install.cmd в папке KTC-PLUGIN\install.

.EXAMPLE
    .\install.ps1
    .\install.ps1 -Channel beta
    .\install.ps1 -PinnedVersion 1.0.0          # закрепить версию на этой машине (откат)
    .\install.ps1 -Unpin
    .\install.ps1 -NetworkRoot 'P:\Библиотека\01_Revit\04_Плагины Revit\KTS-Project_Plugin', '\\server\share\KTC-PLUGIN'
    .\install.ps1 -DeveloperMode -DeveloperBuildRoot 'C:\src\kts-plugin\artifacts\bin'    # из репозитория
#>
[CmdletBinding()]
param(
    # Пути к сетевой папке в порядке предпочтения (буква диска, затем UNC).
    [string[]] $NetworkRoot,

    [ValidateSet('stable', 'beta')]
    [string] $Channel,

    [string] $PinnedVersion,
    [switch] $Unpin,

    [switch] $DeveloperMode,
    [string] $DeveloperBuildRoot,
    [ValidateSet('Debug', 'Release')]
    [string] $DeveloperConfiguration,
    [switch] $DisableDeveloperMode,

    # Версии Revit; по умолчанию — все найденные на машине.
    [ValidateSet(2022, 2023, 2024, 2025, 2026, 2027)]
    [int[]] $RevitVersions,

    # Папка со сборками Loader (подпапки R2022…R2027) и клиентом (Client). По умолчанию — рядом со скриптом
    # или artifacts\loader и artifacts\client репозитория.
    [string] $LoaderSource,

    # Не ставить клиент KTC (только для отладки).
    [switch] $NoClient,

    [switch] $SkipDownload,

    # ЭКСПЕРИМЕНТ: изоляция зависимостей Revit 2026+ (UseRevitContext=False в KTC.addin).
    # Повторный запуск без флага выключает изоляцию. См. docs/ARCHITECTURE.md, раздел «Изоляция».
    [switch] $Isolated,

    # Для тестов и нестандартных профилей.
    [string] $AddinsRoot,
    [string] $LocalRoot
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$DefaultNetworkRoot = 'P:\Библиотека\01_Revit\04_Плагины Revit\KTS-Project_Plugin'
$SupportedYears = 2022, 2023, 2024, 2025, 2026, 2027
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)

function Join-Parts([string[]] $parts) { [System.IO.Path]::Combine($parts) }

if (-not $AddinsRoot) { $AddinsRoot = Join-Parts @($env:APPDATA, 'Autodesk', 'Revit', 'Addins') }
if (-not $LocalRoot) { $LocalRoot = Join-Parts @($env:LOCALAPPDATA, 'kts-project-plugin', 'KTC') }

function Get-InstalledRevitYears {
    $years = @()
    foreach ($year in $SupportedYears) {
        $candidates = @()
        if ($env:ProgramFiles) { $candidates += Join-Parts @($env:ProgramFiles, 'Autodesk', "Revit $year", 'Revit.exe') }
        if ($env:ProgramData) { $candidates += Join-Parts @($env:ProgramData, 'Autodesk', 'Revit', 'Addins', "$year") }
        foreach ($c in $candidates) {
            if (Test-Path -LiteralPath $c) { $years += $year; break }
        }
    }
    return $years
}

function Get-LoaderSourceDir([int] $year) {
    $candidates = @()
    if ($LoaderSource) { $candidates += Join-Parts @($LoaderSource, "R$year") }
    $candidates += Join-Parts @($PSScriptRoot, "R$year")
    $repoArtifacts = Join-Parts @((Split-Path -Parent $PSScriptRoot), 'artifacts', 'loader')
    $config = if ($DeveloperConfiguration) { $DeveloperConfiguration } else { 'Release' }
    $candidates += Join-Parts @($repoArtifacts, ('{0}.R{1}' -f $config, ($year % 100)))
    $candidates += Join-Parts @($repoArtifacts, ('Debug.R{0}' -f ($year % 100)))
    foreach ($c in $candidates) {
        if (Test-Path -LiteralPath (Join-Parts @($c, 'KtsProjectPlugin.Loader.dll'))) { return $c }
    }
    return $null
}

function Get-ClientSourceDir {
    $candidates = @()
    if ($LoaderSource) { $candidates += Join-Parts @($LoaderSource, 'Client') }
    $candidates += Join-Parts @($PSScriptRoot, 'Client')
    $repoClient = Join-Parts @((Split-Path -Parent $PSScriptRoot), 'artifacts', 'client')
    $candidates += Join-Parts @($repoClient, 'Release')
    $candidates += Join-Parts @($repoClient, 'Debug')
    foreach ($c in $candidates) {
        if (Test-Path -LiteralPath (Join-Parts @($c, 'KtsProjectPlugin.Client.exe'))) { return $c }
    }
    return $null
}

function Test-IsWindows { [System.Environment]::OSVersion.Platform -eq [System.PlatformID]::Win32NT }

function Install-Client {
    $source = Get-ClientSourceDir
    if (-not $source) {
        Write-Warning 'Не найдена сборка клиента KTC (папка Client). Клиент не установлен.'
        return
    }
    # Работающий клиент держит свои файлы — останавливаем.
    Get-Process -Name 'KtsProjectPlugin.Client' -ErrorAction SilentlyContinue | ForEach-Object {
        try { $_.Kill(); $_.WaitForExit(5000) | Out-Null } catch { }
    }
    $clientDir = Join-Parts @($LocalRoot, 'client')
    New-Item -ItemType Directory -Path $clientDir -Force | Out-Null
    Get-ChildItem -LiteralPath $clientDir -Force | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
    Copy-Item -Path (Join-Parts @($source, '*')) -Destination $clientDir -Recurse -Force
    $exe = Join-Parts @($clientDir, 'KtsProjectPlugin.Client.exe')
    Write-Host "Клиент KTC установлен в $clientDir" -ForegroundColor Green

    if (Test-IsWindows) {
        # Автозапуск при входе в Windows для текущего пользователя (права администратора не нужны).
        $run = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
        Set-ItemProperty -LiteralPath $run -Name 'KTC' -Value ('"' + $exe + '" --background')
        Start-Process -FilePath $exe -ArgumentList '--show'
        Write-Host '  автозапуск при входе в Windows включён, клиент запущен (значок в трее)'
    }
}

function Read-JsonFile([string] $path) {
    if (-not (Test-Path -LiteralPath $path)) { return $null }
    try {
        return [System.IO.File]::ReadAllText($path, [System.Text.Encoding]::UTF8) | ConvertFrom-Json
    }
    catch {
        Write-Warning "Не удалось прочитать $path : $($_.Exception.Message)"
        return $null
    }
}

function Get-JsonValue($object, [string] $name) {
    if ($null -ne $object -and $object.PSObject.Properties[$name]) { return $object.$name }
    return $null
}

function Install-Loader([int] $year) {
    $source = Get-LoaderSourceDir $year
    if (-not $source) {
        Write-Warning "Revit $year : не найдена сборка Loader (R$year). Пропуск."
        return $false
    }
    $addinsDir = Join-Parts @($AddinsRoot, "$year")
    $loaderDir = Join-Parts @($addinsDir, 'KTC')
    New-Item -ItemType Directory -Path $loaderDir -Force | Out-Null
    try {
        foreach ($file in Get-ChildItem -LiteralPath $source -File) {
            if ($file.Name -eq 'KTC.addin') {
                $addin = [System.IO.File]::ReadAllText($file.FullName, [System.Text.Encoding]::UTF8)
                if ($Isolated -and $year -ge 2026) {
                    $settings = "  <ManifestSettings>`r`n    <UseRevitContext>False</UseRevitContext>`r`n    <ContextName>KTC</ContextName>`r`n  </ManifestSettings>`r`n</RevitAddIns>"
                    $addin = $addin.Replace('</RevitAddIns>', $settings)
                    Write-Host "Revit $year : включена изоляция контекста (эксперимент)" -ForegroundColor Yellow
                }
                [System.IO.File]::WriteAllText((Join-Parts @($addinsDir, 'KTC.addin')), $addin, $Utf8NoBom)
            }
            elseif ($file.Extension -in '.dll', '.json', '.pdb') {
                Copy-Item -LiteralPath $file.FullName -Destination (Join-Parts @($loaderDir, $file.Name)) -Force
            }
        }
    }
    catch {
        Write-Warning "Revit $year : не удалось обновить Loader ($($_.Exception.Message)). Закройте Revit $year и запустите установку ещё раз."
        return $false
    }
    Write-Host "Revit $year : Loader установлен в $loaderDir" -ForegroundColor Green
    return $true
}

function Get-TargetVersion($manifest, [string] $channel, [string] $pinned) {
    if ($pinned) { return $pinned }
    $channels = Get-JsonValue $manifest 'channels'
    if ($channel -eq 'beta') {
        $beta = Get-JsonValue $channels 'beta'
        if ($beta) { return $beta }
    }
    return (Get-JsonValue $channels 'stable')
}

function Install-Release([string] $networkRoot, [string] $version, [int] $year) {
    $source = Join-Parts @($networkRoot, 'releases', $version, "R$year")
    $versionDir = Join-Parts @($LocalRoot, 'versions', $version)
    $target = Join-Parts @($versionDir, "R$year")
    if (Test-Path -LiteralPath (Join-Parts @($target, 'KtsProjectPlugin.Host.dll'))) { return }
    if (-not (Test-Path -LiteralPath (Join-Parts @($source, 'KtsProjectPlugin.Host.dll')))) {
        Write-Warning "Revit $year : в сетевой папке нет версии $version ($source)."
        return
    }
    # Во временную папку и переименование — так же, как это делает Loader.
    $temp = Join-Parts @($LocalRoot, 'versions', ('.tmp-' + [guid]::NewGuid().ToString('N')))
    Copy-Item -LiteralPath $source -Destination $temp -Recurse
    New-Item -ItemType Directory -Path $versionDir -Force | Out-Null
    $changelog = Join-Parts @($networkRoot, 'releases', $version, 'CHANGELOG.md')
    if (Test-Path -LiteralPath $changelog) { Copy-Item -LiteralPath $changelog -Destination $versionDir -Force }
    if (Test-Path -LiteralPath $target) {
        Remove-Item -LiteralPath $temp -Recurse -Force
    }
    else {
        [System.IO.Directory]::Move($temp, $target)
    }
    Write-Host "Revit $year : версия $version скачана" -ForegroundColor Green
}

# --- Версии Revit --------------------------------------------------------------------------------

if (-not $RevitVersions) { $RevitVersions = @(Get-InstalledRevitYears) }
if ($RevitVersions.Count -eq 0) {
    throw 'Не найден ни один Revit 2022–2027. Укажите версии явно: -RevitVersions 2024,2025'
}
Write-Host ('Версии Revit: ' + ($RevitVersions -join ', '))

$running = @(Get-Process -Name 'Revit' -ErrorAction SilentlyContinue)
if ($running.Count -gt 0) {
    Write-Warning 'Revit запущен. Loader для открытых версий Revit может не обновиться — закройте Revit и повторите установку.'
}

# --- bootstrap.json ------------------------------------------------------------------------------

New-Item -ItemType Directory -Path $LocalRoot -Force | Out-Null
$bootstrapFile = Join-Parts @($LocalRoot, 'bootstrap.json')
$existing = Read-JsonFile $bootstrapFile

if (-not $NetworkRoot) {
    $roots = @()
    $existingRoots = Get-JsonValue $existing 'networkRoots'
    if ($existingRoots) { $roots += $existingRoots }
    if ($roots.Count -eq 0) { $roots += $DefaultNetworkRoot }
    # Если скрипт запущен из сетевой папки (KTC-PLUGIN\install), запоминаем и этот путь — это может быть UNC.
    $scriptRoot = Split-Path -Parent $PSScriptRoot
    if ((Test-Path -LiteralPath (Join-Parts @($scriptRoot, 'manifest.json'))) -and ($roots -notcontains $scriptRoot)) {
        $roots += $scriptRoot
    }
    $NetworkRoot = $roots
}

$channelValue = if ($Channel) { $Channel } elseif (Get-JsonValue $existing 'channel') { Get-JsonValue $existing 'channel' } else { 'stable' }
$pinnedValue = if ($Unpin) { $null } elseif ($PinnedVersion) { $PinnedVersion } else { Get-JsonValue $existing 'pinnedVersion' }
$devMode = if ($DisableDeveloperMode) { $false } elseif ($DeveloperMode) { $true } else { [bool](Get-JsonValue $existing 'developerMode') }
$devRoot = if ($DeveloperBuildRoot) { $DeveloperBuildRoot } else { Get-JsonValue $existing 'developerBuildRoot' }
$devConfig = if ($DeveloperConfiguration) { $DeveloperConfiguration } elseif (Get-JsonValue $existing 'developerConfiguration') { Get-JsonValue $existing 'developerConfiguration' } else { 'Debug' }
if ($devMode -and -not $devRoot) { throw 'Для режима разработчика укажите -DeveloperBuildRoot (папка artifacts\bin репозитория).' }

$bootstrap = [ordered]@{
    schemaVersion          = 1
    networkRoots           = @($NetworkRoot)
    channel                = $channelValue
    pinnedVersion          = $pinnedValue
    developerMode          = $devMode
}
if ($devRoot) {
    $bootstrap.developerBuildRoot = $devRoot
    $bootstrap.developerConfiguration = $devConfig
}
# Версии Revit на машине: для них клиент скачивает обновления.
$years = @()
$existingYears = Get-JsonValue $existing 'revitVersions'
if ($existingYears) { $years += $existingYears }
$years += $RevitVersions
$bootstrap.revitVersions = @($years | ForEach-Object { [int]$_ } | Sort-Object -Unique)
foreach ($name in 'manifestTimeoutMs', 'keepVersions') {
    $value = Get-JsonValue $existing $name
    if ($value) { $bootstrap[$name] = $value }
}
[System.IO.File]::WriteAllText($bootstrapFile, ($bootstrap | ConvertTo-Json -Depth 5), $Utf8NoBom)
Write-Host "Конфиг: $bootstrapFile"
Write-Host ('  сетевая папка: ' + (@($NetworkRoot) -join ' | '))
$channelText = "  канал: $channelValue"
if ($pinnedValue) { $channelText += ", закреплена версия $pinnedValue" }
Write-Host $channelText
if ($devMode) { Write-Host "  режим разработчика: $devRoot ($devConfig)" -ForegroundColor Yellow }

# --- Loader --------------------------------------------------------------------------------------

$installed = 0
foreach ($year in $RevitVersions) {
    if (Install-Loader $year) { $installed++ }
}

# --- Предварительное скачивание версии ------------------------------------------------------------

if (-not $SkipDownload -and -not $devMode) {
    $availableRoot = @($NetworkRoot) | Where-Object { Test-Path -LiteralPath (Join-Parts @($_, 'manifest.json')) } | Select-Object -First 1
    if ($availableRoot) {
        $manifestFile = Join-Parts @($availableRoot, 'manifest.json')
        $manifest = Read-JsonFile $manifestFile
        # Кэш манифеста: по нему Loader учитывает откат и minLoaderVersion, не обращаясь к сети.
        $cacheDir = Join-Parts @($LocalRoot, 'cache')
        New-Item -ItemType Directory -Path $cacheDir -Force | Out-Null
        Copy-Item -LiteralPath $manifestFile -Destination (Join-Parts @($cacheDir, 'manifest.json')) -Force
        $version = Get-TargetVersion $manifest $channelValue $pinnedValue
        if ($version) {
            foreach ($year in $RevitVersions) { Install-Release $availableRoot $version $year }
        }
    }
    else {
        Write-Warning 'Сетевая папка недоступна: версию платформы скачает клиент KTC, когда появится сеть.'
    }
}

if ($installed -eq 0) { throw 'Loader не установлен ни для одной версии Revit.' }

# --- Клиент KTC ----------------------------------------------------------------------------------

if (-not $NoClient) { Install-Client }

Write-Host 'Установка завершена. Запустите Revit — на ленте появится вкладка KTC.' -ForegroundColor Green
