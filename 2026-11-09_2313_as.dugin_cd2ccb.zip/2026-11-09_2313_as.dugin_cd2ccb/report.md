# Отчёт об ошибке KTC

- Дата: 2026-11-09 23:13:34
- Пользователь: as.dugin
- Машина: TER-KTS-007
- Роль: Инженер ВК
- Активный документ: KTS_RU_ШаблонПроекта_ОВиК_r2022_v3.0
- Команда: ios.settings

## Описание

(не заполнено)

## Ошибка

```
System.MissingMethodException: Метод не найден: "Void System.Nullable`1..ctor(Boolean)".
   в KtsProjectPlugin.Modules.Ios.Views.MergeWindow..ctor(Document doc, SystemNameSettings sn)
   в KtsProjectPlugin.Modules.Ios.Views.MergeWindow.Edit(Document doc, SystemNameSettings sn, Window owner)
   в KtsProjectPlugin.Modules.Ios.Views.SettingsWindow.OnMergeGearClick(Object sender, RoutedEventArgs e)
   в System.Windows.EventRoute.InvokeHandlersImpl(Object source, RoutedEventArgs args, Boolean reRaised)
   в System.Windows.UIElement.RaiseEventImpl(DependencyObject sender, RoutedEventArgs args)
   в System.Windows.Controls.Primitives.ButtonBase.OnClick()
   в System.Windows.Controls.Button.OnClick()
   в System.Windows.Controls.Primitives.ButtonBase.OnMouseLeftButtonUp(MouseButtonEventArgs e)
   в System.Windows.RoutedEventArgs.InvokeHandler(Delegate handler, Object target)
   в System.Windows.RoutedEventHandlerInfo.InvokeHandler(Object target, RoutedEventArgs routedEventArgs)
   в System.Windows.EventRoute.InvokeHandlersImpl(Object source, RoutedEventArgs args, Boolean reRaised)
   в System.Windows.UIElement.ReRaiseEventAs(DependencyObject sender, RoutedEventArgs args, RoutedEvent newEvent)
   в System.Windows.UIElement.OnMouseUpThunk(Object sender, MouseButtonEventArgs e)
   в System.Windows.RoutedEventArgs.InvokeHandler(Delegate handler, Object target)
   в System.Windows.RoutedEventHandlerInfo.InvokeHandler(Object target, RoutedEventArgs routedEventArgs)
   в System.Windows.EventRoute.InvokeHandlersImpl(Object source, RoutedEventArgs args, Boolean reRaised)
   в System.Windows.UIElement.RaiseEventImpl(DependencyObject sender, RoutedEventArgs args)
   в System.Windows.UIElement.RaiseTrustedEvent(RoutedEventArgs args)
   в System.Windows.Input.InputManager.ProcessStagingArea()
   в System.Windows.Input.InputManager.ProcessInput(InputEventArgs input)
   в System.Windows.Input.InputProviderSite.ReportInput(InputReport inputReport)
   в System.Windows.Interop.HwndMouseInputProvider.ReportInput(IntPtr hwnd, InputMode mode, Int32 timestamp, RawMouseActions actions, Int32 x, Int32 y, Int32 wheel)
   в System.Windows.Interop.HwndMouseInputProvider.FilterMessage(IntPtr hwnd, WindowMessage msg, IntPtr wParam, IntPtr lParam, Boolean& handled)
   в System.Windows.Interop.HwndSource.InputFilterMessage(IntPtr hwnd, Int32 msg, IntPtr wParam, IntPtr lParam, Boolean& handled)
   в MS.Win32.HwndWrapper.WndProc(IntPtr hwnd, Int32 msg, IntPtr wParam, IntPtr lParam, Boolean& handled)
   в MS.Win32.HwndSubclass.DispatcherCallbackOperation(Object o)
   в System.Windows.Threading.ExceptionWrapper.InternalRealCall(Delegate callback, Object args, Int32 numArgs)
   в System.Windows.Threading.ExceptionWrapper.TryCatchWhen(Object source, Delegate callback, Object args, Int32 numArgs, Delegate catchHandler)
   в System.Windows.Threading.Dispatcher.LegacyInvokeImpl(DispatcherPriority priority, TimeSpan timeout, Delegate method, Object args, Int32 numArgs)
   в MS.Win32.HwndSubclass.SubclassWndProc(IntPtr hwnd, Int32 msg, IntPtr wParam, IntPtr lParam)
   в MS.Win32.UnsafeNativeMethods.DispatchMessage(MSG& msg)
   в System.Windows.Threading.Dispatcher.PushFrameImpl(DispatcherFrame frame)
   в System.Windows.Window.ShowHelper(Object booleanBox)
   в System.Windows.Window.ShowDialog()
   в KtsProjectPlugin.Modules.Ios.Commands.SettingsCommand.Run(CommandContext context)
   в KtsProjectPlugin.Core.Commands.KtsCommand.Autodesk.Revit.UI.IExternalCommand.Execute(ExternalCommandData commandData, String& message, ElementSet elements)
```

## Окружение

- Revit: 2022
- Сборка Revit: 22.1.70.9
- Язык Revit: Russian
- Платформа: 1.2.1
- Loader: 1.0.0
- Канал: stable
- Режим разработчика: False
- Папка Host: C:\Users\as.dugin\AppData\Local\kts-project-plugin\KTC\versions\1.2.5\R2022
- Сетевая папка: P:\Библиотека\01_Revit\04_Плагины Revit\KTS-Project_Plugin
- Роль: Инженер ВК
- ОС: Microsoft Windows 10.0.17763 
- .NET: .NET Framework 4.8.4811.0
- Процесс: x64
- Пользователь: as.dugin
- Машина: TER-KTS-007
- Культура UI: ru-RU
- Модуль Library: 1.2.1 Loaded
- Модуль Audit: 1.2.1 Loaded
- Модуль Ios: 1.2.1 Loaded
